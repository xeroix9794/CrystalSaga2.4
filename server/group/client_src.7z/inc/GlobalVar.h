#pragma once

class LEEditor;

extern LEEditor g_Editor;
