#pragma once

enum eFormTemplete
{
	enumLoginForm = 0,
	enumMainForm,
	enumSelectChaForm,
	enumEditorForm,
	enumSwitchSceneForm,
	enumCreateChaForm,
	enumSelectForm,
};
