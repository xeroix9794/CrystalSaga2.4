//---------------------------------------------------------
// EntityScript.h Created by knight-gong 2005.5.12.
#pragma once

#ifndef _ENTITY_SCRIPT_H_
#define _ENTITY_SCRIPT_H_

#include "Script.h"
//---------------------------------------------------------

extern BOOL RegisterEntityScript();

//---------------------------------------------------------

#endif // _ENTITY_SCRIPT_H_