// NpcScript.h Created by knight-gongjian 2004.11.30.
//---------------------------------------------------------
#pragma once

#ifndef _NPCSCRIPT_H_
#define _NPCSCRIPT_H_

#include "Script.h"
//---------------------------------------------------------

extern BOOL RegisterNpcScript();

//---------------------------------------------------------

#endif // _NPCSCRIPT_H_