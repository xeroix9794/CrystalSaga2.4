// stdafx.h : include file for standard system include files,
// or project specific include files that are used frequently, but
// are changed infrequently
//

#pragma once


#include <iostream>
#include <tchar.h>
#include <math.h>
#include "stdio.h"
#include "stdlib.h"

#include "dbccommon.h"
#include "util.h"
#include "tryutil.h"

#include "i18n.h"

// Add by lark.li 20080730 begin
#include "pi_Alloc.h"
#include "pi_Memory.h"
// End
