// MapTrigger.h Created by knight-gongjian 2005.1.28.
//---------------------------------------------------------
#pragma once

#ifndef _MAPTRIGGER_H_
#define _MAPTRIGGER_H_

//---------------------------------------------------------

namespace mission
{
	class CTrigger
	{
	public:
		CTrigger();
		virtual ~CTrigger();

	private:

	};

	class CMapTrigger
	{
	public:
		CMapTrigger();
		~CMapTrigger();

	private:

	};

}

//---------------------------------------------------------
#endif // _MAPTRIGGER_H_