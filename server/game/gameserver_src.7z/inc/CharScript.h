// CharScript.h Created by knight-gongjian 2004.12.13.
//---------------------------------------------------------
#pragma once

#ifndef _CHARSCRIPT_H_
#define _CHARSCRIPT_H_

#include "Script.h"
//---------------------------------------------------------

extern BOOL RegisterCharScript();
//---------------------------------------------------------

#endif // _CHARSCRIPT_H_