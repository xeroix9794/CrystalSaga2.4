//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by GameServer.rc
//
#define IDD_REPORT_VIEW                 101
#define IDD_DLG_MAIN                    102
#define IDD_MAP_VIEW                    103
#define IDI_ICON1                       104
#define IDC_FPS                         1004
#define IDC_EDIT1                       1005
#define IDC_EXEC                        1006
#define IDC_MAP_LIST                    1007
#define IDC_GATE_LIST                   1008
#define IDC_GAMEDB                      1009
#define IDC_CLEAR                       1010
#define IDC_MAP_LIST2                   1011
#define IDC_PK_LIST                     1011
#define IDC_ACTIVEOBJ                   1012
#define IDC_PLAYER                      1013
#define IDC_OTHER                       1014
#define IDC_LOOP                        1015
#define IDC_ACTIVEOUNIT                 1016
#define IDC_RUNFLAG                     1017
#define IDC_OTHER2                      1018
#define IDC_PID                         1018
#define IDC_MAPXY                       1019
#define IDC_MOUSEXY                     1020
#define IDC_BUT_ZOOM1                   1021
#define IDC_BUTTON2                     1022
#define IDC_BUT_ZOOM2                   1022
#define IDC_VIEWLOG                     1023
#define IDC_CHECK_NAME                  1024
#define IDC_CHECK_VIEW                  1024
#define IDC_CHECK1                      1025
#define IDC_CHECK_CHA_LOG               1025
#define IDC_RES_DIR                     1026
#define IDC_BTN_LOG                     1026
#define IDC_RES_DIR2                    1027
#define IDC_CHECK_SCRIPT                1027
#define IDC_RES_DIR3                    1028
#define IDC_CHECK_NET                   1028
#define IDC_PK_CNT                      1029
#define IDC_CHECK_NET2                  1029
#define IDC_CHECK_NET_PROC              1029
#define IDC_DBLOG_LEFT                  1030
#define IDC_DBLOG_LEFT2                 1031
#define IDC_PERLOGCNT                   1031
#define IDC_STATIC_GROUP1               1032
#define IDC_STATIC_GROUP2               1033
#define IDC_STATIC_LBL1                 1034
#define IDC_STATIC_LBL2                 1035
#define IDC_STATIC_2                    1036
#define IDC_STATIC_LBL3                 1036
#define IDC_STATIC_LBL4                 1037
#define IDC_STATIC_LBL5                 1038
#define IDC_STATIC_LBL6                 1039
#define IDC_STATIC_LBL7                 1040
#define IDC_STATIC_LBL8                 1041
#define IDC_STATIC_LBL9                 1042
#define IDC_STATIC_LBL10                1043
#define IDC_STATIC_LBL11                1044
#define IDC_STATIC_LBL12                1045
#define IDC_STATIC_LBL13                1046
#define IDC_LIST_LOG                    1047

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        105
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1049
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
