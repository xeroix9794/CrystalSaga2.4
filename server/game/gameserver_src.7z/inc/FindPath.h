#pragma once


#define MAX_PATH_STEP	128
#define STEP_LIMIT		128*128  // 256 * 256
