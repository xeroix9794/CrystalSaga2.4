// MapTrigger.cpp Created by knight-gongjian 2005.1.28.
//---------------------------------------------------------

#include "MapTrigger.h"

//---------------------------------------------------------

namespace mission
{


}

