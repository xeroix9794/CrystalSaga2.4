#include "stdafx.h"
#include "character.h"
#include "gameapp.h"

BOOL g_bLogHarmRec = FALSE;

