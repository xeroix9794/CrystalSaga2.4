#pragma once

#ifndef _LUAFUNC_H_
#define _LUAFUNC_H_

#include <dbccommon.h>

#include "i18n.h"

extern BOOL RegisterLuaFunc();

#endif // _LUAFUNC_H_

