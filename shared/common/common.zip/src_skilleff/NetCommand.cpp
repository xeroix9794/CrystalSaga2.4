#include "NetCommand.h"

map<int, pair<string, string>> MsgMap;
