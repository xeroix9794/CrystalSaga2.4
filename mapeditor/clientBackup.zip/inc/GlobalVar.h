#pragma once

class MPEditor;

extern MPEditor g_Editor;
