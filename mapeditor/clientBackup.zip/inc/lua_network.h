

inline int lua_Connect(lua_State *L)
{
    return 1;
}
